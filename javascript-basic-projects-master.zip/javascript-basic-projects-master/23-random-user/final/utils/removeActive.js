export default function removeActive(items) {
  items.forEach((btn) => btn.classList.remove('active'));
}
