console.log('products starter');
