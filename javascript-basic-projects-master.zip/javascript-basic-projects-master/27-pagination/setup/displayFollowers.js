const display = () => {}

export default display
