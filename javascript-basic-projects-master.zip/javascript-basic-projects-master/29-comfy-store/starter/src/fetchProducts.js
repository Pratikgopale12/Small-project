import { allProductsUrl } from './utils.js';

const fetchProducts = async () => {};

export default fetchProducts;
