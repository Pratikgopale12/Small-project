import { formatPrice, getElement } from '../utils.js';

const addToCartDOM = () => {};

export default addToCartDOM;
